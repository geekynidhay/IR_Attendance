"""
Admin Panel for IR Attendance
Manage licenses, generate codes, revoke access.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import json
import sys
from license_manager import LicenseManager
from system_utils import SystemUtils
from encryption_utils import EncryptionUtils
from pathlib import Path

class AdminPanel:
    def __init__(self, root):
        self.root = root
        self.root.title("IR Attendance - Admin Panel")
        self.root.geometry("800x600")
        
        # Set Icon
        try:
            icon_path = SystemUtils.resource_path("Admin Icon.png")
            if Path(icon_path).exists():
                icon_img = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, icon_img)
        except Exception as e:
            print(f"Icon Load fail: {e}")
            
        # Password Protection
        self.ask_password()
        
        # Hardcoded Credentials for Portability
        admin_config = {
            "database_url": "https://attendance-68878-default-rtdb.asia-southeast1.firebasedatabase.app/",
            "api_secret": "apng5Iuu7ijd8QYZLTj9ZZ4UGsmYE6wLaenzhFRx"
        }
        self.lm = LicenseManager(manual_config=admin_config)
        
        self.create_ui()
        self.refresh_list()
        
    def ask_password(self):
        """Prompt for password before showing UI"""
        # Hide root first
        self.root.withdraw()
        
        # Simple Dialog (custom window for better control or just simple input)
        # Using simpledialog requires import
        from tkinter import simpledialog
        
        password = simpledialog.askstring("Login", "Enter Admin Password:", show='*')
        
        if password == "Nidhay@2003":
            self.root.deiconify()
        else:
            messagebox.showerror("Error", "Incorrect Password")
            sys.exit(0)
        
    def create_ui(self):
        tab_control = ttk.Notebook(self.root)
        
        self.tab_generate = ttk.Frame(tab_control)
        self.tab_users = ttk.Frame(tab_control)
        self.tab_requests = ttk.Frame(tab_control)
        tab_control.add(self.tab_requests, text='Pending Requests')
        tab_control.add(self.tab_generate, text='Generate Activation')
        tab_control.add(self.tab_users, text='Manage Users')
        tab_control.pack(expand=1, fill="both")
        
        self.setup_requests_tab()
        self.setup_generate_tab()
        self.setup_users_tab()
        
    def setup_requests_tab(self):
        frame = ttk.Frame(self.tab_requests, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(fill=tk.X, pady=5)
        ttk.Button(btn_frame, text="Refresh Requests", command=self.refresh_requests).pack(side=tk.LEFT)
        ttk.Button(btn_frame, text="Approve Selected", command=self.approve_direct_request).pack(side=tk.LEFT, padx=10)
        
        # Treeview
        columns = ('machine_id', 'username', 'timestamp')
        self.req_tree = ttk.Treeview(frame, columns=columns, show='headings')
        self.req_tree.heading('machine_id', text='Machine ID')
        self.req_tree.heading('username', text='Username / Name')
        self.req_tree.heading('timestamp', text='Time')
        
        self.req_tree.column('machine_id', width=150)
        self.req_tree.column('username', width=150)
        self.req_tree.column('timestamp', width=150)
        
        self.req_tree.pack(fill=tk.BOTH, expand=True)
        
    def setup_generate_tab(self):
        frame = ttk.Frame(self.tab_generate, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(frame, text="Generate Activation Code", font=('Arial', 14, 'bold')).pack(pady=10)
        
        ttk.Label(frame, text="Username (as received):").pack(anchor=tk.W)
        self.user_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.user_var, width=40).pack(anchor=tk.W, pady=5)
        
        ttk.Label(frame, text="Request Code (from Client):").pack(anchor=tk.W)
        self.req_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.req_var, width=60).pack(anchor=tk.W, pady=5)
        
        ttk.Button(frame, text="Generate & Activate", command=self.generate_code).pack(pady=20)
        
        ttk.Label(frame, text="Activation Code to Send:").pack(anchor=tk.W)
        self.result_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.result_var, width=40, font=('Arial', 12, 'bold')).pack(anchor=tk.W, pady=5)
        
    def setup_users_tab(self):
        frame = ttk.Frame(self.tab_users, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(fill=tk.X, pady=5)
        ttk.Button(btn_frame, text="Refresh List", command=self.refresh_list).pack(side=tk.LEFT)
        ttk.Button(btn_frame, text="Revoke Selected", command=self.revoke_user).pack(side=tk.LEFT, padx=10)
        
        # Treeview
        columns = ('machine_id', 'username', 'status', 'last_seen', 'ip', 'location')
        self.tree = ttk.Treeview(frame, columns=columns, show='headings')
        self.tree.heading('machine_id', text='Machine ID')
        self.tree.heading('username', text='Username')
        self.tree.heading('status', text='Status')
        self.tree.heading('last_seen', text='Last Seen')
        self.tree.heading('ip', text='IP Address')
        self.tree.heading('location', text='Location')
        
        self.tree.column('machine_id', width=120)
        self.tree.column('username', width=100)
        self.tree.column('status', width=70)
        self.tree.column('last_seen', width=130)
        self.tree.column('ip', width=100)
        self.tree.column('location', width=150)
        
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def generate_code(self):
        user = self.user_var.get().strip()
        req = self.req_var.get().strip()
        
        if not user or not req:
            messagebox.showwarning("Error", "Fill all fields")
            return
            
        success, result = self.lm.activate_license(req, user)
        if success:
            self.result_var.set(result)
            messagebox.showinfo("Success", f"Activation Code Generated: {result}")
            self.refresh_list()
        else:
            messagebox.showerror("Error", result)
            
    def refresh_list(self):
        self.refresh_users()
        self.refresh_requests()

    def refresh_users(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
            
        data = self.lm.list_licenses()
        if data:
            for mid, info in data.items():
                self.tree.insert('', tk.END, values=(
                    mid,
                    info.get('username', 'N/A'),
                    info.get('status', 'Unknown'),
                    info.get('last_seen', 'Never'),
                    info.get('ip', 'Unknown'),
                    info.get('location', 'Unknown')
                ))
                
    def revoke_user(self):
        selected = self.tree.selection()
        if not selected:
            return
            
        item = self.tree.item(selected[0])
        mid = item['values'][0]
        
        if messagebox.askyesno("Confirm", f"Revoke license for {mid}?"):
            success, msg = self.lm.revoke_license(mid)
            if success:
                messagebox.showinfo("Success", "User permanently removed from list")
                self.refresh_list()
            else:
                messagebox.showerror("Error", msg)

    def refresh_requests(self):
        for i in self.req_tree.get_children():
            self.req_tree.delete(i)
            
        data = self.lm.list_activation_requests()
        if data:
            for mid, info in data.items():
                self.req_tree.insert('', tk.END, values=(
                    mid,
                    info.get('username', 'N/A'),
                    info.get('timestamp', 'N/A')
                ))

    def approve_direct_request(self):
        selected = self.req_tree.selection()
        if not selected:
            return
            
        item = self.req_tree.item(selected[0])
        mid = item['values'][0]
        username = item['values'][1]
        
        if messagebox.askyesno("Confirm", f"Approve activation for {username} ({mid})?"):
            # 1. Activate using Machine ID (mid) as the request code
            success, result = self.lm.activate_license(mid, username)
            if success:
                # 2. Delete the request
                self.lm.delete_activation_request(mid)
                messagebox.showinfo("Success", f"User {username} Activated!")
                self.refresh_list()
            else:
                messagebox.showerror("Error", result)


if __name__ == "__main__":
    root = tk.Tk()
    app = AdminPanel(root)
    root.mainloop()
