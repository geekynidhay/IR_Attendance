"""
Image Viewer Mode for IR Attendance application
Main viewer interface with folder navigation, image display, and controls
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import pyperclip
from config import config
from folder_navigator import FolderNavigator
from image_controls import ImageControls, ImageDisplay
import time
import keyboard
import os
import shutil
import server  # Import the new server module
import pyautogui

from footer import Footer

class ViewerMode:
    """Image Viewer Mode UI and logic"""
    
    def __init__(self, parent, on_back_callback, window_manager, license_manager, is_auto=True):
        self.on_back_callback = on_back_callback
        self.parent = parent
        self.window_manager = window_manager
        self.lm = license_manager
        self.is_auto = is_auto
        self.frame = ttk.Frame(parent)
        
        # Default Data Directory
        self.data_dir = Path("C:/IR Attendance")
        if not self.data_dir.exists():
            try:
                self.data_dir.mkdir(parents=True, exist_ok=True)
            except:
                pass
        
        # State
        self.current_images = []
        self.current_image_index = -1
        self.current_brightness = 100
        self.current_zoom = 100
        self.target_window = None
        self.is_auto_running = False
        self.auto_job = None
        
        # Start the local server for mobile mirroring
        self.server_ip = server.start_server()
        
        self.create_ui()
        
        # Bind keyboard events
        self.parent.bind('<Control-equal>', lambda e: self.zoom_in())
        self.parent.bind('<Control-plus>', lambda e: self.zoom_in())
        self.parent.bind('<Control-minus>', lambda e: self.zoom_out())
        self.parent.bind('<Control-0>', lambda e: self.reset_zoom())
        self.parent.bind('<Control-MouseWheel>', self.on_mouse_wheel)
        self.parent.bind('<Key-z>', self.prompt_zoom)
        self.parent.bind('<Key-b>', self.prompt_brightness)
        self.parent.bind('<Key-B>', self.prompt_brightness)
        self.parent.bind('<Key-m>', self.toggle_mark)
        self.parent.bind('<Key-M>', self.toggle_mark)
        if hasattr(self, 'folder_tree'):
            self.folder_tree.bind('<Key-b>', self.prompt_brightness)
            self.folder_tree.bind('<Key-B>', self.prompt_brightness)
            self.folder_tree.bind('<Key-m>', self.toggle_mark)
            self.folder_tree.bind('<Key-M>', self.toggle_mark)
        if hasattr(self, 'image_canvas'):
            self.image_canvas.bind('<Key-b>', self.prompt_brightness)
            self.image_canvas.bind('<Key-B>', self.prompt_brightness)
            self.image_canvas.bind('<Key-m>', self.toggle_mark)
            self.image_canvas.bind('<Key-M>', self.toggle_mark)
        
        if self.is_auto:
            self.parent.bind('<Control-Return>', self.execute_macro)
        else:
            self.parent.bind('<Return>', self.execute_macro)
    
    def create_ui(self):
        """Create the viewer mode UI matching the layout"""
        # Main container with footer
        self.content_container = ttk.Frame(self.frame)
        self.content_container.pack(fill=tk.BOTH, expand=True)
        
        # Footer
        self.footer = Footer(self.frame)
        self.footer.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Header
        header_frame = ttk.Frame(self.content_container)
        header_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(header_frame, text="💻 Computer Attendance", 
                 font=('Arial', 16, 'bold')).pack(side=tk.LEFT)
        
        # Server Info Label
        ips = " / ".join(self.server_ip) if isinstance(self.server_ip, list) else self.server_ip
        ttk.Label(header_frame, text=f"Mirror IPs: {ips}", 
                 font=('Arial', 10), foreground='blue').pack(side=tk.LEFT, padx=20)
        
        ttk.Button(header_frame, text="← Back to Menu", 
                  command=self.on_back_callback).pack(side=tk.RIGHT)
        
        # Batch Selection Dropdown
        batch_sel_frame = ttk.Frame(header_frame)
        batch_sel_frame.pack(side=tk.RIGHT, padx=20)
        
        ttk.Label(batch_sel_frame, text="Select Batch:").pack(side=tk.LEFT, padx=5)
        self.batch_var = tk.StringVar()
        self.batch_combo = ttk.Combobox(batch_sel_frame, textvariable=self.batch_var, width=20, state='readonly')
        self.batch_combo.pack(side=tk.LEFT, padx=5)
        self.batch_combo.bind('<<ComboboxSelected>>', lambda e: self.load_selected_batch())
        
        ttk.Button(batch_sel_frame, text="↺", width=3, command=self.refresh_batch_list).pack(side=tk.LEFT)
        
        # ── Batch Information Header ---
        self.batch_info_frame = ttk.Frame(self.content_container, padding=(10, 0))
        self.batch_info_frame.pack(fill=tk.X)
        
        # Using a distinct style for the batch info
        info_inner = ttk.Frame(self.batch_info_frame, borderwidth=1, relief="solid", padding=5)
        info_inner.pack(fill=tk.X)
        
        self.lbl_batch_id = ttk.Label(info_inner, text="Batch ID: ---", font=('Arial', 12, 'bold'))
        self.lbl_batch_id.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(info_inner, text="|", font=('Arial', 12)).pack(side=tk.LEFT)
        
        self.lbl_batch_in = ttk.Label(info_inner, text="In Time: --:--", font=('Arial', 11))
        self.lbl_batch_in.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(info_inner, text="To", font=('Arial', 11)).pack(side=tk.LEFT)
        
        self.lbl_batch_out = ttk.Label(info_inner, text="Out Time: --:--", font=('Arial', 11))
        self.lbl_batch_out.pack(side=tk.LEFT, padx=10)
        
        # ── Auto Attendance Control Panel ──────────────────────────────────────
        if self.is_auto:
            self.acp = ttk.Frame(self.content_container, padding=(10, 5))
            self.acp.pack(fill=tk.X)
            
            ttk.Label(self.acp, text="Timer (sec):", font=('Arial', 10, 'bold')).pack(side=tk.LEFT, padx=(10, 5))
            self.timer_var = tk.StringVar(value="5")
            ttk.Entry(self.acp, textvariable=self.timer_var, width=5, font=('Arial', 10)).pack(side=tk.LEFT, padx=5)
            
            ttk.Label(self.acp, text="Auto Attendance:").pack(side=tk.LEFT, padx=(20, 5))
            self.auto_status_var = tk.StringVar(value="OFF")
            self.auto_status_lbl = tk.Label(self.acp, textvariable=self.auto_status_var, 
                                            fg="red", font=('Arial', 12, 'bold'))
            self.auto_status_lbl.pack(side=tk.LEFT)
            
            self.auto_guideline = ttk.Label(self.acp, text="To start the auto attendance please press A", 
                                            font=('Arial', 10, 'bold'), foreground='blue')
            self.auto_guideline.pack(side=tk.RIGHT, padx=10)

        # --- Instructions ---
        inst_frame = ttk.Frame(self.content_container)
        inst_frame.pack(fill=tk.X, padx=10, pady=5)
        
        inst_text = "Navigation: ↓ Next | ↑ Prev | → Next Img | ← Prev Img | Ctrl+Scroll: Zoom | Ctrl+Space: Focus"
        if self.is_auto:
            inst_text += " | Ctrl+Enter: Auto-Type | A: Auto Mode"
        else:
            inst_text += " | Enter: Auto-Type"
            
        ttk.Label(inst_frame, 
                 text=inst_text,
                 font=('Arial', 9)).pack()
        
        # Main content area
        main_frame = ttk.Frame(self.content_container)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Left panel: Folder tree
        left_frame = ttk.LabelFrame(main_frame, text="Folders", width=200)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 5))
        left_frame.pack_propagate(False)
        
        # Filter Toggle
        filter_frame = ttk.Frame(left_frame)
        filter_frame.pack(fill=tk.X, pady=(2, 5))
        self.show_marked_only_var = tk.BooleanVar(value=False)
        self.toggle_btn = tk.Button(filter_frame, text="Show Marked Only: OFF", bg='gray', fg='white', 
                                    font=('Arial', 9, 'bold'), relief=tk.FLAT, command=self.toggle_marked_filter)
        self.toggle_btn.pack(fill=tk.X, padx=5)
        
        # Folder tree with scrollbar
        tree_scroll = ttk.Scrollbar(left_frame)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.folder_tree = ttk.Treeview(left_frame, yscrollcommand=tree_scroll.set)
        self.folder_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll.config(command=self.folder_tree.yview)

        # Bind Left/Right on Treeview to prevent naive selection change (Jumping to top)
        self.folder_tree.bind('<Left>', lambda e: self.block_tree_nav(e, 'left'))
        self.folder_tree.bind('<Right>', lambda e: self.block_tree_nav(e, 'right'))

        
        # Initialize folder navigator
        self.navigator = FolderNavigator(self.folder_tree, self.on_subfolder_change)
        
        # Macro button
        copy_btn_frame = ttk.Frame(left_frame)
        copy_btn_frame.pack(fill=tk.X, pady=5)
        
        btn_text = "Run Macro (Ctrl+Enter)" if self.is_auto else "Run Macro (Enter)"
        ttk.Button(copy_btn_frame, text=btn_text, 
                  command=self.execute_macro).pack(fill=tk.X, padx=2)
        
        # Center-left panel: Brightness control (vertical)
        brightness_frame = ttk.LabelFrame(main_frame, text="Brightness", width=100)
        brightness_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        brightness_frame.pack_propagate(False)
        
        # Vertical brightness control
        bright_controls = ttk.Frame(brightness_frame)
        bright_controls.pack(expand=True)
        
        # Default Brightness Field
        ttk.Label(bright_controls, text="Default").pack(pady=(0, 2))
        self.default_brightness_var = tk.StringVar(value=config.get("global_default_brightness", ""))
        self.default_brightness_entry = ttk.Entry(bright_controls, textvariable=self.default_brightness_var, width=5)
        self.default_brightness_entry.pack(pady=(0, 10))
        self.default_brightness_var.trace_add("write", self.on_default_brightness_change)

        tk.Button(bright_controls, text="+", font=('Arial', 12, 'bold'), width=3, relief=tk.RAISED,
                  command=self.increase_brightness).pack(pady=5)
        
        self.brightness_var = tk.IntVar(value=100)
        self.brightness_slider = ttk.Scale(bright_controls, from_=200, to=0,
                                          orient=tk.VERTICAL, variable=self.brightness_var,
                                          command=self.on_brightness_change, length=300)
        self.brightness_slider.pack(pady=5)
        
        tk.Button(bright_controls, text="-", font=('Arial', 14, 'bold'), width=3, relief=tk.RAISED,
                  command=self.decrease_brightness).pack(pady=5)
        
        self.brightness_label = ttk.Label(bright_controls, text="100%")
        self.brightness_label.pack(pady=5)
        
        # Right panel: Preview and Image display
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Info section (Batch ID, Attendance ID, Sr No)
        info_wrapper = ttk.Frame(right_frame)
        info_wrapper.pack(fill=tk.X, pady=(0, 5))
        
        # Row 2 Wrapper for Attendance ID and Sr No
        row2_frame = ttk.Frame(info_wrapper)
        row2_frame.pack(side=tk.TOP, fill=tk.X)
        
        # Sr No
        sr_frame = ttk.LabelFrame(row2_frame, text="Sr No")
        sr_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        self.sr_label = ttk.Label(sr_frame, text="---", font=('Arial', 12, 'bold'), anchor=tk.CENTER)
        self.sr_label.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Attendance ID
        attendance_frame = ttk.LabelFrame(row2_frame, text="Attendance ID")
        attendance_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.preview_label = ttk.Label(attendance_frame, text="---", font=('Arial', 14, 'bold'), anchor=tk.CENTER)
        self.preview_label.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Marked Counter
        marked_counter_frame = ttk.LabelFrame(row2_frame, text="Marked")
        marked_counter_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 0))
        self.marked_count_label = ttk.Label(marked_counter_frame, text="0", font=('Arial', 12, 'bold'), anchor=tk.CENTER)
        self.marked_count_label.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Main image display
        image_frame = ttk.LabelFrame(right_frame, text="Image")
        image_frame.pack(fill=tk.BOTH, expand=True)
        
        self.image_canvas = tk.Canvas(image_frame, bg='gray')
        self.image_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # ── Full Screen Auto Overlay ──────────────────────────────────────────
        if self.is_auto:
            self.auto_overlay = tk.Toplevel(self.parent)
            self.auto_overlay.withdraw()
            self.auto_overlay.overrideredirect(True)
            self.auto_overlay.attributes("-topmost", True)
            self.auto_overlay.attributes("-alpha", 0.85)
            self.auto_overlay.config(bg='#000000')
            
            self.overlay_status_lbl = tk.Label(self.auto_overlay, text="IDLE", font=('Arial', 24, 'bold'), fg='#888888', bg='#000000')
            self.overlay_status_lbl.pack(pady=(100, 10))
            
            self.overlay_id_lbl = tk.Label(self.auto_overlay, text="---", font=('Arial', 80, 'bold'), fg='white', bg='#000000')
            self.overlay_id_lbl.pack(pady=10)
            
            self.overlay_timer_lbl = tk.Label(self.auto_overlay, text="---", font=('Arial', 120, 'bold'), fg='#4CAF50', bg='#000000')
            self.overlay_timer_lbl.pack(pady=(10, 0))
            
            self.overlay_progress_canvas = tk.Canvas(self.auto_overlay, height=20, bg='#222222', highlightthickness=0)
            self.overlay_progress_canvas.pack(fill=tk.X, padx=100, pady=20)
            self.overlay_progress_bar = self.overlay_progress_canvas.create_rectangle(0, 0, 0, 20, fill='#4CAF50')
            
            tk.Label(self.auto_overlay, text="Press 'A' to Emergency Stop", font=('Arial', 14), fg='#555555', bg='#000000').pack(side=tk.BOTTOM, pady=50)
        
        # Initialize image display with encryption key
        key = self.lm.encryption_key if self.lm else None
        self.image_display = ImageDisplay(self.image_canvas, self.preview_label, 
                                         on_view_change=self.update_server_image,
                                         encryption_key=key)
        
        # Current image info
        info_frame = ttk.Frame(self.content_container)
        info_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.info_label = ttk.Label(info_frame, text="No image loaded", font=('Arial', 9))
        self.info_label.pack()
        
        # Register the dropdown refresh (MUST BE AT THE END)
        self.refresh_batch_list()

    def refresh_batch_list(self, force_load=False):
        """Scan C:/IR Attendance for folders and update dropdown"""
        if not self.data_dir.exists():
            self.batch_combo['values'] = []
            return
            
        marked_folders = config.get('marked_folders', [])
        display_folders = []
        
        for folder in self.data_dir.iterdir():
            if folder.is_dir():
                name = folder.name
                # Check if any subfolder is marked
                has_marked = False
                try:
                    for subfolder in folder.iterdir():
                        if subfolder.is_dir() and str(subfolder) in marked_folders:
                            has_marked = True
                            break
                except:
                    pass
                
                if has_marked:
                    display_folders.append(f"{name} 🔴")
                else:
                    display_folders.append(name)
        
        folders = sorted(display_folders)
        self.batch_combo['values'] = folders
        
        # Auto-select last one or first one
        last_batch = config.get('last_batch_path', '')
        if last_batch:
            last_name = Path(last_batch).name
            # Find matching display name (with or without indicator)
            match = next((f for f in folders if f.startswith(last_name)), None)
            if match:
                self.batch_var.set(match)
                if force_load or not hasattr(self, '_first_load_done'):
                    self._first_load_done = True
                    self.load_selected_batch()

    def load_selected_batch(self):
        """Load the folder selected in the dropdown and parse its name"""
        batch_display_name = self.batch_var.get()
        if not batch_display_name:
            return
            
        # Strip indicator if present
        batch_name = batch_display_name.replace(" 🔴", "").replace(" [M]", "")
        folder_path = self.data_dir / batch_name
        if folder_path.exists():
            # Parse folder name: "45741 - 09.30 To 18.30"
            try:
                # 1. Get Batch ID (before first hyphen)
                parts = batch_name.split(' - ')
                batch_id = parts[0].strip()
                self.lbl_batch_id.config(text=f"Batch ID: {batch_id}")
                
                # 2. Get Times
                if len(parts) > 1:
                    time_part = parts[1] # "09.30 To 18.30"
                    time_parts = time_part.lower().split(' to ')
                    if len(time_parts) == 2:
                        self.lbl_batch_in.config(text=f"In Time: {time_parts[0].strip()}")
                        self.lbl_batch_out.config(text=f"Out Time: {time_parts[1].strip()}")
                    else:
                        self.lbl_batch_in.config(text=f"Time: {time_part}")
                        self.lbl_batch_out.config(text="")
                else:
                    self.lbl_batch_in.config(text="")
                    self.lbl_batch_out.config(text="")
            except Exception as e:
                print(f"Error parsing folder name: {e}")
                self.lbl_batch_id.config(text=f"Batch: {batch_name}")
            
            # Save as last used
            config.set('last_batch_path', str(folder_path))
            
            # Load the folder into the navigator
            self.navigator.load_folder(str(folder_path), show_marked_only=self.show_marked_only_var.get())
            
            # Auto-select first item and focus tree
            children = self.folder_tree.get_children()
            if children:
                self.folder_tree.selection_set(children[0])
                self.folder_tree.focus(children[0])
                self.folder_tree.focus_set() # Focus the tree for arrow navigation
                # The selection_set above will trigger on_tree_select -> on_subfolder_change automatically


    def browse_folder(self):
        """REMOVED: Using dropdown instead"""
        pass
    
    def load_folder(self):
        """REMOVED: Using load_selected_batch instead"""
        pass
    
    def on_subfolder_change(self, subfolder_path):
        """Handle subfolder selection change"""
        if not subfolder_path:
            return
            
        # Load images from subfolder
        self.current_images = self.navigator.get_images_in_current_subfolder()
        self.current_image_index = -1
        
        # Update Subfolder Name Label
        subfolder_name = subfolder_path.name
        self.image_display.update_subfolder_label(subfolder_name)
        
        # Check marked state
        subfolder_str = str(subfolder_path)
        marked_folders = config.get('marked_folders', [])
        self.update_ui_marked_state(subfolder_str in marked_folders)
        
        # Update Sr No Label
        try:
            total = len(self.navigator.subfolders)
            current = self.navigator.subfolders.index(subfolder_path) + 1
            self.sr_label.config(text=f"{current} / {total}")
        except ValueError:
            self.sr_label.config(text="---")
            
        # Update Marked Counter
        self.update_marked_count()
        
        # ── PERSISTENCE: Restore per-subfolder brightness & image index ──
        saved = config.get_subfolder_settings(subfolder_name)
        global_val = self.default_brightness_var.get().strip()
        
        has_override = saved.get('has_override', False)
        if has_override:
            self.current_brightness = saved.get('brightness', 100)
        else:
            if global_val:
                try:
                    self.current_brightness = int(global_val)
                except ValueError:
                    self.current_brightness = 100
            else:
                self.current_brightness = 100
                
        self.current_zoom = saved.get('zoom', 100)
        saved_index = saved.get('image_index', 0)
        
        self.brightness_var.set(self.current_brightness)
        self.brightness_label.config(text=f"{self.current_brightness}%")
        
        # Load saved image (or first image as fallback)
        if self.current_images:
            self.current_image_index = min(saved_index, len(self.current_images) - 1)
            self.load_current_image()
        else:
            self.image_display.clear()
            self.info_label.config(text=f"Subfolder: {subfolder_name} (No images)")
            server.update_image(None)  # Clear server image
    
    def load_current_image(self):
        """Load and display the current image"""
        if self.current_image_index < 0 or self.current_image_index >= len(self.current_images):
            return
        
        image_path = self.current_images[self.current_image_index]
        success = self.image_display.load_image(image_path, self.current_brightness, 
                                               self.current_zoom)
        
        if success:
            subfolder_name = self.navigator.get_current_subfolder_name()
            self.info_label.config(
                text=f"Subfolder: {subfolder_name} | Image: {image_path.name} | "
                     f"{self.current_image_index + 1}/{len(self.current_images)}"
            )
            # Update server with new loaded image
            server.update_image(self.image_display.current_image)
    
    def navigate_left(self, event=None):
        """Navigate to previous image (Left arrow)"""
        if not self.current_images:
            return
        
        if self.current_image_index > 0:
            self.current_image_index -= 1
            self.load_current_image()
            self._save_current_subfolder_state()
    
    def navigate_right(self, event=None):
        """Navigate to next image (Right arrow)"""
        if not self.current_images:
            return
        
        if self.current_image_index < len(self.current_images) - 1:
            self.current_image_index += 1
            self.load_current_image()
            self._save_current_subfolder_state()
    
    def navigate_up(self, event=None):
        """Navigate to previous subfolder (Up arrow)"""
        self.navigator.navigate_up()
    
    def navigate_down(self, event=None):
        """Navigate to next subfolder (Down arrow)"""
        self.navigator.navigate_down()
    
    def increase_brightness(self):
        """Increase brightness by 1%"""
        new_value = min(200, self.current_brightness + 1)
        self.brightness_var.set(new_value)
        self.on_brightness_change(new_value)
    
    def decrease_brightness(self):
        """Decrease brightness by 1%"""
        new_value = max(0, self.current_brightness - 1)
        self.brightness_var.set(new_value)
        self.on_brightness_change(new_value)
    
    def adjust_brightness(self, val):
        """Update brightness and redraw image"""
        try:
            new_brightness = int(float(val))
            self.current_brightness = new_brightness
            self.brightness_label.config(text=f"{new_brightness}%")
            
            # Apply to current image
            self.image_display.set_brightness(new_brightness)
            
            # Update server with modified image
            server.update_image(self.image_display.current_image)
            
            # Save to config for this subfolder
            subfolder_name = self.navigator.get_current_subfolder_name()
            if subfolder_name:
                config.set_subfolder_settings(subfolder_name, new_brightness, self.current_zoom, override=True)
        except:
            pass

    def on_brightness_change(self, value):
        """Handle brightness slider change"""
        new_brightness = int(float(value))
        self.current_brightness = new_brightness
        self.brightness_label.config(text=f"{new_brightness}%")
        
        # Apply to current image
        self.image_display.set_brightness(new_brightness)
        
        # Update server with modified image
        server.update_image(self.image_display.current_image)
        
        # Save to config for this subfolder (including current image index)
        self._save_current_subfolder_state(override=True)

    def on_default_brightness_change(self, *args):
        """Handle global default brightness entry change"""
        val = self.default_brightness_var.get().strip()
        config.set("global_default_brightness", val)
        
        sf_name = self.navigator.get_current_subfolder_name()
        if not sf_name: return
        saved = config.get_subfolder_settings(sf_name)
        
        if not saved.get('has_override', False):
            if val:
                try:
                    new_val = int(val)
                    self.current_brightness = new_val
                    self.brightness_var.set(new_val)
                    self.brightness_label.config(text=f"{new_val}%")
                    if hasattr(self, 'image_display'):
                        self.image_display.set_brightness(new_val)
                    self.update_server_image()
                except ValueError:
                    pass
            else:
                self.current_brightness = 100
                self.brightness_var.set(100)
                self.brightness_label.config(text="100%")
                if hasattr(self, 'image_display'):
                    self.image_display.set_brightness(100)
                self.update_server_image()
    
    def on_zoom_change(self, value):
        """Handle zoom change"""
        self.current_zoom = int(float(value))
        
        # Apply to current image
        self.image_display.set_zoom(self.current_zoom)
        
        # Update server with modified image (visible portion)
        self.update_server_image()
        
        # Save to config for this subfolder
        subfolder_name = self.navigator.get_current_subfolder_name()
        if subfolder_name:
            config.set_subfolder_settings(subfolder_name, self.current_brightness, self.current_zoom)

    def zoom_in(self, event=None):
        """Increase zoom by 10%"""
        self.on_zoom_change(self.current_zoom + 10)

    def zoom_out(self, event=None):
        """Decrease zoom by 10%"""
        self.on_zoom_change(self.current_zoom - 10)

    def reset_zoom(self, event=None):
        """Reset zoom to 100%"""
        self.on_zoom_change(100)

    def on_mouse_wheel(self, event):
        """Handle Ctrl+MouseWheel for zoom"""
        if event.delta > 0:
            self.zoom_in()
        else:
            self.zoom_out()

    def prompt_zoom(self, event=None):
        """Prompt user for absolute zoom percentage"""
        from tkinter import simpledialog
        val = simpledialog.askinteger("Zoom", "Enter zoom percentage:", 
                                     parent=self.frame, minvalue=5, maxvalue=2000)
        if val is not None:
            self.on_zoom_change(val)
        
        # Restore focus to navigation
        self.parent.focus_force()
        self.folder_tree.focus_set()
        selection = self.folder_tree.selection()
        if selection:
            self.folder_tree.focus(selection[0])
        return 'break'
    
    def execute_macro(self, event=None):
        """
        Execute Data Entry Macro:
        1. Alt+Tab to switch to previous window (Data Entry App)
        2. Type subfolder name
        3. Bring this window back to front
        """
        subfolder_name = self.navigator.get_current_subfolder_name()
        if not subfolder_name:
            messagebox.showwarning("Warning", "No subfolder selected")
            return
            
        try:
            if self.is_auto:
                # 1. Switch to previous window (Alt+Tab)
                keyboard.press('alt')
                keyboard.press('tab')
                time.sleep(0.05)
                keyboard.release('tab')
                keyboard.release('alt')
                
                # Wait for switch (User requested 0.5-0.6s)
                time.sleep(0.6)
                
                # 2. Type the number (auto-submitted)
                keyboard.write(subfolder_name, delay=0.05)
                time.sleep(0.2)
                
                # 4. Switch back to this window
                keyboard.press('alt')
                keyboard.press('tab')
                time.sleep(0.05)
                keyboard.release('tab')
                keyboard.release('alt')
                
                time.sleep(0.5)
                
                # 5. Bring this window back to front and FOCUS THE TREE
                self.window_manager.bring_to_front()
                self.parent.focus_force()          # Force OS-level focus to our window
                self.folder_tree.focus_set()       # Then give tree keyboard focus
                # Also ensure a student is selected to keep navigation active
                selection = self.folder_tree.selection()
                if selection:
                    self.folder_tree.focus(selection[0])
            else:
                # Manual Macro: Alt+Tab -> Type ID -> Alt+Tab back
                keyboard.press('alt')
                keyboard.press('tab')
                time.sleep(0.05)
                keyboard.release('tab')
                keyboard.release('alt')
                
                time.sleep(0.6)
                
                keyboard.write(subfolder_name, delay=0.05)
                time.sleep(0.2)
                
                # Switch back
                keyboard.press('alt')
                keyboard.press('tab')
                time.sleep(0.05)
                keyboard.release('tab')
                keyboard.release('alt')
                
                time.sleep(0.5)
                
                self.window_manager.bring_to_front()
                self.parent.focus_force()
                self.folder_tree.focus_set()
                selection = self.folder_tree.selection()
                if selection:
                    self.folder_tree.focus(selection[0])
            
        except Exception as e:
            messagebox.showerror("Error", f"Macro failed: {e}")
        return 'break'
            
    def update_ui_marked_state(self, is_marked):
        """Change UI colors to indicate marked state"""
        color = 'red' if is_marked else ''
        bg_color = '#4a0000' if is_marked else 'gray'
        
        self.preview_label.config(foreground=color)
        self.lbl_batch_id.config(foreground=color)
        self.sr_label.config(foreground=color)
        self.marked_count_label.config(foreground=color)
        self.image_canvas.config(bg=bg_color)
        
        # Update labels in the info_inner frame too
        for child in self.batch_info_frame.winfo_children():
            if isinstance(child, ttk.Frame): # inner frame
                for inner_child in child.winfo_children():
                    if isinstance(inner_child, ttk.Label):
                        try:
                            # Use style if it's a themed widget, or just foreground
                            inner_child.configure(foreground=color)
                        except:
                            pass

    def prompt_brightness(self, event=None):
        """Prompt user for absolute brightness percentage"""
        from tkinter import simpledialog
        val = simpledialog.askinteger("Brightness", "Enter brightness percentage:", 
                                     parent=self.frame, minvalue=0, maxvalue=500)
        if val is not None:
            self.brightness_var.set(val)
            self.on_brightness_change(val)
            
        # Restore focus to navigation
        self.parent.focus_force()
        self.folder_tree.focus_set()
        selection = self.folder_tree.selection()
        if selection:
            self.folder_tree.focus(selection[0])
        return 'break'
            
    def toggle_mark(self, event=None):
        """Toggle mark state for current subfolder"""
        if not self.navigator.current_subfolder:
            return
            
        subfolder_str = str(self.navigator.current_subfolder)
        marked_folders = config.get('marked_folders', [])
        
        if subfolder_str in marked_folders:
            marked_folders.remove(subfolder_str)
            is_marked = False
        else:
            marked_folders.append(subfolder_str)
            is_marked = True
            
        config.set('marked_folders', marked_folders)
        
        # Find tree item and update tags
        for child in self.folder_tree.get_children(''):
            values = self.folder_tree.item(child, 'values')
            if values and values[0] == subfolder_str:
                tags = ('subfolder', 'marked') if is_marked else ('subfolder',)
                self.folder_tree.item(child, tags=tags)
                self.folder_tree.see(child)
                break
        
        # Update UI colors immediately
        self.update_ui_marked_state(is_marked)
        self.update_marked_count()
        
        # Refresh dropdown to show/hide 🔴 WITHOUT disturbing the tree selection
        self._refresh_batch_dropdown_only()
        return 'break'

    def toggle_marked_filter(self):
        """Toggle the marked-only filter for the tree"""
        new_val = not self.show_marked_only_var.get()
        self.show_marked_only_var.set(new_val)
        
        if new_val:
            self.toggle_btn.config(text="Show Marked Only: ON", bg='#e53935')
        else:
            self.toggle_btn.config(text="Show Marked Only: OFF", bg='gray')
            
        # Reload current batch
        batch_display_name = self.batch_var.get()
        if batch_display_name:
            self.load_selected_batch()

    def update_marked_count(self):
        """Update the counter showing how many folders in current batch are marked"""
        if not hasattr(self.navigator, 'subfolders') or not self.navigator.subfolders:
            self.marked_count_label.config(text="0")
            return
            
        marked_folders = config.get('marked_folders', [])
        count = sum(1 for subfolder in self.navigator.subfolders if str(subfolder) in marked_folders)
        self.marked_count_label.config(text=str(count))
    
    def show(self):
        """Show the viewer mode frame"""
        self.frame.pack(fill=tk.BOTH, expand=True)
        self.refresh_batch_list(force_load=True)
        # Ensure keyboard bindings are active
        self.parent.focus_set()
        # Add global hotkey for A only in Auto Mode
        if self.is_auto:
            try:
                keyboard.add_hotkey('a', lambda: self.parent.after(1, self.toggle_auto_attendance))
            except:
                pass
    
    def hide(self):
        """Hide the viewer mode frame"""
        self.frame.pack_forget()
        # Remove global hotkey
        if self.is_auto:
            try:
                keyboard.remove_hotkey('a')
            except:
                pass

    def block_tree_nav(self, event, direction):
        """Handle tree navigation to prevent default behavior"""
        if direction == 'left':
            self.navigate_left(event)
        else:
            self.navigate_right(event)
        return 'break' # Stop event propagation

    def update_server_image(self):
        """Update the server with the full brightness-adjusted image (no zoom/crop)"""
        if hasattr(self, 'image_display') and self.image_display:
            # Send processed_image (brightness applied, full resolution) for clean mirror
            server.update_image(self.image_display.current_image)

    def _save_current_subfolder_state(self, override=None):
        """Persist current brightness, zoom, and image index for the active subfolder"""
        subfolder_name = self.navigator.get_current_subfolder_name()
        if subfolder_name:
            config.set_subfolder_settings(
                subfolder_name,
                self.current_brightness,
                self.current_zoom,
                self.current_image_index,
                override
            )

    def _refresh_batch_dropdown_only(self):
        """Refresh the batch dropdown display names without triggering tree reload"""
        if not self.data_dir.exists():
            return
        marked_folders = config.get('marked_folders', [])
        display_folders = []
        for folder in self.data_dir.iterdir():
            if folder.is_dir():
                name = folder.name
                has_marked = False
                try:
                    for subfolder in folder.iterdir():
                        if subfolder.is_dir() and str(subfolder) in marked_folders:
                            has_marked = True
                            break
                except:
                    pass
                display_folders.append(f"{name} 🔴" if has_marked else name)
        folders = sorted(display_folders)
        current_val = self.batch_var.get()
        self.batch_combo['values'] = folders
        # Re-select the current batch by matching the base name
        base = current_val.replace(" 🔴", "").replace(" [M]", "").strip()
        match = next((f for f in folders if f.startswith(base)), None)
        if match:
            self.batch_var.set(match)

    # ── Auto Attendance Methods ──────────────────────────────────────────────
    def toggle_auto_attendance(self, event=None):
        if self.is_auto_running:
            self.stop_auto_attendance()
        else:
            self.start_auto_attendance()

    def start_auto_attendance(self):
        try:
            timer_val = float(self.timer_var.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number for the timer.")
            return
            
        self.is_auto_running = True
        self.auto_status_var.set("ON")
        self.auto_status_lbl.config(fg="green")
        self.run_auto_step()

    def stop_auto_attendance(self):
        self.is_auto_running = False
        self.auto_status_var.set("OFF")
        self.auto_status_lbl.config(fg="red")
        if self.auto_job:
            self.parent.after_cancel(self.auto_job)
            self.auto_job = None
        self.auto_overlay.withdraw()

    def sync_overlay(self):
        try:
            x = self.parent.winfo_rootx()
            y = self.parent.winfo_rooty()
            w = self.parent.winfo_width()
            h = self.parent.winfo_height()
            self.auto_overlay.geometry(f"{w}x{h}+{x}+{y}")
        except:
            pass

    def run_auto_step(self):
        if not self.is_auto_running:
            return
            
        current_selection = self.folder_tree.selection()
        if not current_selection:
            self.stop_auto_attendance()
            return
            
        item = current_selection[0]
        subfolder_name = self.folder_tree.item(item, "text")
        
        self.overlay_status_lbl.config(text="CURRENTLY TYPING", fg="#FFC107")
        self.overlay_id_lbl.config(text=subfolder_name)
        self.overlay_timer_lbl.config(text="...")
        self.overlay_progress_canvas.coords(self.overlay_progress_bar, 0, 0, 0, 20)
        self.sync_overlay()
        self.auto_overlay.deiconify()
        
        import threading
        threading.Thread(target=self.threaded_execute_macro, args=(subfolder_name,), daemon=True).start()

    def threaded_execute_macro(self, subfolder_name):
        try:
            # 1. Switch to previous window (Alt+Tab)
            keyboard.press('alt')
            keyboard.press('tab')
            time.sleep(0.05)
            keyboard.release('tab')
            keyboard.release('alt')
            
            # Wait for switch (User requested 0.5-0.6s)
            time.sleep(0.6)
            
            # 2. Type the number (auto-submitted)
            keyboard.write(subfolder_name, delay=0.05)
            time.sleep(0.2)
            
            # 4. Switch back to this window
            keyboard.press('alt')
            keyboard.press('tab')
            time.sleep(0.05)
            keyboard.release('tab')
            keyboard.release('alt')
            
            time.sleep(0.5)
            
            # 5. Wait slightly before showing countdown
            self.parent.after(0, self.start_countdown_for_next)
        except Exception as e:
            self.parent.after(0, lambda: messagebox.showerror("Error", f"Macro failed: {e}"))
            self.parent.after(0, self.stop_auto_attendance)

    def start_countdown_for_next(self):
        if not self.is_auto_running:
            return
            
        self.window_manager.bring_to_front()
        self.parent.focus_force()
        self.folder_tree.focus_set()
        selection = self.folder_tree.selection()
        if selection:
            self.folder_tree.focus(selection[0])
            
        current_selection = self.folder_tree.selection()
        if current_selection:
            item = current_selection[0]
            subfolder_name = self.folder_tree.item(item, "text")
            
            self.overlay_status_lbl.config(text="WAITING / NEXT", fg="#888888")
            self.overlay_id_lbl.config(text=subfolder_name)
            self.sync_overlay()
            self.auto_overlay.deiconify()
            
            try:
                delay = int(float(self.timer_var.get()))
            except:
                delay = 5
                
            self.countdown_val = float(delay)
            self.countdown_start = float(delay)
            self.last_update_time = time.time()
            self._brought_front_this_step = False
            self.update_countdown()

    def update_countdown(self):
        if not self.is_auto_running:
            return
            
        now = time.time()
        dt = now - self.last_update_time
        self.last_update_time = now
        self.countdown_val -= dt
        
        display_sec = max(0, int(self.countdown_val) + 1)
        self.overlay_timer_lbl.config(text=str(display_sec))
        
        # update progress bar
        canvas_width = self.overlay_progress_canvas.winfo_width()
        if canvas_width > 1:
            ratio = max(0, self.countdown_val / self.countdown_start) if self.countdown_start > 0 else 0
            bar_width = int(canvas_width * ratio)
            self.overlay_progress_canvas.coords(self.overlay_progress_bar, 0, 0, bar_width, 20)
        
        if self.countdown_val <= 0:
            self.overlay_timer_lbl.config(text="0")
            self.overlay_progress_canvas.coords(self.overlay_progress_bar, 0, 0, 0, 20)
            
            old_selection = self.folder_tree.selection()
            self.navigator.navigate_down()
            new_selection = self.folder_tree.selection()
            
            if old_selection and new_selection and old_selection[0] == new_selection[0]:
                self.stop_auto_attendance()
                self.parent.after(100, lambda: messagebox.showinfo("Success", "All attendance have been marked successfully!"))
                return
                
            # Wait briefly after navigation for the image to load
            self.parent.after(300, self.run_auto_step)
        else:
            if self.countdown_val <= 1.0 and not getattr(self, '_brought_front_this_step', False):
                try:
                    pyautogui.press('enter')
                    time.sleep(0.05)
                except:
                    pass
                self.window_manager.bring_to_front()
                self.parent.focus_force()
                self.countdown_val = 0.5
                self._brought_front_this_step = True
            
            # Smooth update (~30fps)
            self.auto_job = self.parent.after(33, self.update_countdown)
