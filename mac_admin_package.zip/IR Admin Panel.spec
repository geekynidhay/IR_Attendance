# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['src/admin_panel.py'],
    pathex=[],
    binaries=[],
    datas=[('Admin Icon.png', '.')],
    hiddenimports=['googleapiclient', 'google.auth', 'google_auth_oauthlib', 'tkcalendar', 'openpyxl', 'babel.numbers'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='IR Admin Panel',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='IR Admin Panel',
)
app = BUNDLE(
    coll,
    name='IR Admin Panel.app',
    icon=None,
    bundle_identifier=None,
)
